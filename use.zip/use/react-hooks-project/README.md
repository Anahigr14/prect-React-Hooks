# React Hooks Project

Este proyecto es una demostración de cómo usar los hooks en React, incluyendo un hook personalizado para persistir datos en `localStorage`.

## Hooks Usados

1. **useState**: Para manejar el estado de los datos.
2. **useEffect**: Para realizar efectos secundarios como la persistencia de datos.
3. **useLocalStorage**: Hook personalizado para guardar y recuperar datos de `localStorage`.

## Instalación

Para instalar las dependencias del proyecto, corre el siguiente comando:

```bash
npm install


#### Paso 4: Subir el `README.md` a GitHub



```bash
git add README.md
git commit -m "Agregar documentación en README.md"
git push
