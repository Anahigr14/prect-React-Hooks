// src/hooks/useLocalStorage.js
import { useState } from "react";

// Definimos el hook personalizado
const useLocalStorage = (key, initialValue) => {
  // Recuperar el valor del localStorage si está disponible, o usar el valor inicial
  const storedValue = localStorage.getItem(key);
  const [value, setValue] = useState(storedValue ? JSON.parse(storedValue) : initialValue);

  // Actualizar el valor tanto en el estado como en el localStorage
  const setStoredValue = (newValue) => {
    setValue(newValue);
    localStorage.setItem(key, JSON.stringify(newValue));
  };

  return [value, setStoredValue];
};

export default useLocalStorage;
