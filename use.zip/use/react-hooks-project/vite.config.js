// vite.config.js
export default {
  server: {
    port: 3000  // Cambia el puerto aquí
  }
};
